
package com.gayathri.projects.offerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OfferService {
    public static void main(String[] args) {
        SpringApplication.run(OfferService.class, args);
    }
}
