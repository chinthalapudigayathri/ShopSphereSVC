
package com.gayathri.projects.shipmentservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShipmentService {
    public static void main(String[] args) {
        SpringApplication.run(ShipmentService.class, args);
    }
}
