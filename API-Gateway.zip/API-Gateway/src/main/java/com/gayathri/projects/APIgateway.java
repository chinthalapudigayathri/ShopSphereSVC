
package com.gayathri.projects.apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class APIgateway {
    public static void main(String[] args) {
        SpringApplication.run(APIgateway.class, args);
    }
}
