
package com.gayathri.projects.customerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerService {
    public static void main(String[] args) {
        SpringApplication.run(CustomerService.class, args);
    }
}
